echo "# Smriti's To-Do CLI" > README.md
